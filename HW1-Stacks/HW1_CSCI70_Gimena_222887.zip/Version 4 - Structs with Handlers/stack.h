void push(int stacknum, char x);
char pop(int stachnum);